package com.lti.service;

import java.util.List;

import com.lti.model.Bus;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;

public interface BusService {
	public boolean addUser(User user);
	public List<Bus> findBus(String busSource, String busDestination);
	public boolean chooseBus(Transaction transaction);
	public Ticket displayTicketById(int transactionid);
	public int forgetPassword(String username, String newPassword);
	public boolean deleteBus(int busId);
	public Bus modifyBusByAdmin(Bus bus);
}
