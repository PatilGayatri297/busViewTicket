package com.lti.model;

public class Payment {
	private int transactionId;
	private int accountNumber;
	private int amount;
	private String bankName;
	
	
	public Payment() {
		super();
	}


	public Payment(int transactionId, int accountNumber, int amount, String bankName) {
		super();
		this.transactionId = transactionId;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.bankName = bankName;
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public int getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	@Override
	public String toString() {
		return "Payment [transactionId=" + transactionId + ", accountNumber=" + accountNumber + ", amount=" + amount
				+ ", bankName=" + bankName + "]";
	}
	
	
	
	

}
