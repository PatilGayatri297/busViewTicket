package com.lti.controller;

import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Bus;
import com.lti.model.Payment;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;
import com.lti.service.BusService;

@Controller
public class BusController {
	
	@Autowired
	private Ticket ticket;
	
	@Autowired
	private BusService service;
	
	@Autowired
	private User user;
	
	@Autowired
	private Bus bus;
	
	@Autowired
	private Transaction transaction;
	
	@Autowired
	private Payment payment;
	
	@Autowired 
	JavaMailSender sender;	
	String emailSender="<quadrobus@gmail.com>";
	
	
	
	@RequestMapping(path="/")
	public String indexPage(){
		return "index";
		
	}
	@RequestMapping(path="addUser.do",  method=RequestMethod.POST)
	public String addUser(@RequestParam("useremail")String email, @RequestParam("userpassword") String password, @RequestParam("usermobile")String mobile){
		user.setUserEmail(email);
		user.setUserPassword(password);
		user.setUserMobile(mobile);
		
		boolean result = service.addUser(user);
		if(result){
			return "success";
		}
		return "Error";
	}
	
	@RequestMapping(path="viewBus.do", method=RequestMethod.GET)
	public String readBus(@RequestParam("bussource")String bussource, @RequestParam("busdestination")String busdestination, Model model){
		bus.setBusSource(bussource);
		bus.setBusDestination(busdestination);
		List<Bus> list = service.findBus(bussource, busdestination);
		model.addAttribute("buslist",list);
		System.out.println(list);
		return "viewBus";
	}
	
	@RequestMapping(path="bookSeat", method=RequestMethod.POST)
	public String bookSeat(){
		return "bookSeat";
	}
	

	@RequestMapping(path="viewTicket", method=RequestMethod.GET)
	public String viewTicket(@RequestParam("transactionid") int id, Model model){
		List<Ticket> list1 = (List<Ticket>) service.displayTicketById(id);
		model.addAttribute("ticketlist", list1);
		System.out.println(list1);
		return "viewTicket";
	}
	
	
	
	  @RequestMapping(value="mail.shop", method = RequestMethod.GET) 
	  public String genOtp() 
	  { 
		  return "Otp"; 
	  }
	  

	  @RequestMapping(value="validate.shop", method=RequestMethod.GET)
	   public String validateOtp( @RequestParam("otp2")String otp2,@RequestParam("customerPassword")String customerPassword, HttpSession session) {
		Object obj= session.getAttribute("otp");
		String mail = (String)session.getAttribute("customerMail");
		String otp=null;
		if(obj!=null) {
			 otp = obj.toString();
		}		
		if(otp.contentEquals(otp2))
		{
			int result = service.forgetPassword(mail, customerPassword);
			if(result>0){
				return "redirect:index";
			}
			else {
			return "password not updated";
			}
		}
		else
		{
			return "redirect:mail.shop";
		}
	}
	  
	 @RequestMapping(path="otp.do", method=RequestMethod.GET)
	 public String otppage(){
		 return "otp";
	 }

		
		@RequestMapping(path="mailotp.shop", method=RequestMethod.GET)
		public String sentOtp(Model model, @RequestParam("emailToRecipient") final String emailToRecipient, HttpSession session ) {
			 
			int randomPin   =(int) (Math.random()*9000)+1000; 
		     final String otp1  = String.valueOf(randomPin); 
		     
	        // Logging The Email Form Parameters For Debugging Purpose
	        //System.out.println("\nReceipient?= " + emailToRecipient + ", Subject?= " + emailSubject + ", Message?= " + emailMessage + "\n");
	 
	        sender.send(new MimeMessagePreparator() {
	            public void prepare(MimeMessage mimeMessage) throws Exception {
	 
	                MimeMessageHelper mimeMsgHelperObj = new MimeMessageHelper(mimeMessage, true, "UTF-8");             
	                mimeMsgHelperObj.setTo(emailToRecipient);
	                mimeMsgHelperObj.setFrom(emailSender);               
	                mimeMsgHelperObj.setText(otp1);
	                mimeMsgHelperObj.setSubject("Your OTP is: ");             
	            }
	        });
	        session.setAttribute("otp", otp1);
	        session.setAttribute("customerMail", emailToRecipient);
	        System.out.println("\nMessage Send Successfully.... Hurrey!\n");
	        model.addAttribute("msg","Mail Sent!");
	       return "forgotpassword";
		}
		
		
		@RequestMapping(path="deletebus.do", method=RequestMethod.GET)
		public String removeBus(@RequestParam("busid") int id)
		{
			boolean result= service.deleteBus(id);
			if(result){
				return "redirect:viewBus";
			}
			return "Error";
			
		}
		
		@RequestMapping()
		public void sendAttachmentToEmail()
		{
		
			String to = "usermail";
			String from = "quadrobus@gmail.com";// Sender's email ID needs to be mentioned

		      final String username = "manishaspatil";//change accordingly
		      final String password = "******";//change accordingly

		      // Assuming you are sending email through relay.jangosmtp.net
		      String host = "relay.jangosmtp.net";

		      Properties props = new Properties();
		      props.put("mail.smtp.auth", "true");
		      props.put("mail.smtp.starttls.enable", "true");
		      props.put("mail.smtp.host", host);
		      props.put("mail.smtp.port", "25");

		      // Get the Session object.
		      Session session = Session.getInstance(props,
		         new javax.mail.Authenticator() {
		            protected PasswordAuthentication getPasswordAuthentication() {
		               return new PasswordAuthentication(username, password);
		            }
		         });

		      try {
		         // Create a default MimeMessage object.
		         Message message = new MimeMessage(session);

		         // Set From: header field of the header.
		         message.setFrom(new InternetAddress(from));

		         // Set To: header field of the header.
		         message.setRecipients(Message.RecipientType.TO,
		            InternetAddress.parse(to));

		         // Set Subject: header field
		         message.setSubject("Testing Subject");

		         // Create the message part
		         BodyPart messageBodyPart = new MimeBodyPart();

		         // Now set the actual message
		         messageBodyPart.setText("This is message body");

		         // Create a multipar message
		         Multipart multipart = new MimeMultipart();

		         // Set text message part
		         multipart.addBodyPart(messageBodyPart);

		         // Part two is attachment
		         messageBodyPart = new MimeBodyPart();
		         String filename = "/home/manisha/file.txt";
		         DataSource source = new FileDataSource(filename);
		         messageBodyPart.setDataHandler(new DataHandler(source));
		         messageBodyPart.setFileName(filename);
		         multipart.addBodyPart(messageBodyPart);

		         // Send the complete message parts
		         message.setContent(multipart);

		         // Send message
		         Transport.send(message);

		         System.out.println(" Message sent successfully!!!!");
		  
		      } catch (MessagingException e) {
		         throw new RuntimeException(e);
		      }
		   }
		
		@RequestMapping(path="updatebus.do", method=RequestMethod.POST)
		public String updateBus(@RequestParam("busid") int busid,@RequestParam("bustype") String type, @RequestParam("bussource") String source, 
				@RequestParam("busdestination") String destination,@RequestParam("busfare") int fare, @RequestParam("busseats") int seat)
		{
			bus.setBusId(busid);
			bus.setBusType(type);
			bus.setBusSource(source);
			bus.setBusDestination(destination);
			bus.setBusFare(fare);
			bus.setBusSeats(seat);
			
			Bus result=service.modifyBusByAdmin(bus);
			if(result!=null){
				return "redirect:updatebus";
			}
			return "Error";
			
		}
		

		@RequestMapping(path="dopayment.do",method=RequestMethod.GET)
		public String payPayment(@RequestParam("transactionid") int id,@RequestParam("accountnumber") int accountno,
				@RequestParam("amount") int amount, @RequestParam("bankname") String bank)
		{
			payment.getTransactionId();
			payment.setAccountNumber(accountno);
			payment.setAmount(amount);
			payment.setBankName(bank);
			
			boolean result=service.paymentProcess(payment);
			if(result){
				return "success";
			}
			return "Error";
			
		}
		
		
		}












	

	
	
	
	
	
	
	
	
	
	
