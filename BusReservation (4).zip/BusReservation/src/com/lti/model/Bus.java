package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="bus")
public class Bus {
	@Id
	@Column(name="busid")
	private int busId;
	
	@Column(name="bustype")
	private String busType;
	
	@Column(name="bussource")
	private String busSource;
	
	@Column(name="busdestination")
	private String busDestination;
	
	@Column(name="busfare")
	private int busFare;
	
	@Column(name="busseats")
	private int busSeats;
	
	@Column(name="busdate")
	private String busDate;
	
	
	public Bus() {
		super();
	}



	public int getBusId() {
		return busId;
	}



	public void setBusId(int busId) {
		this.busId = busId;
	}



	public Bus(int busId, String busType, String busSource, String busDestination, int busFare, int busSeats,
			String busDate) {
		super();
		this.busId = busId;
		this.busType = busType;
		this.busSource = busSource;
		this.busDestination = busDestination;
		this.busFare = busFare;
		this.busSeats = busSeats;
		this.busDate = busDate;
	}



	public String getBusType() {
		return busType;
	}


	public void setBusType(String busType) {
		this.busType = busType;
	}


	public String getBusSource() {
		return busSource;
	}


	public void setBusSource(String busSource) {
		this.busSource = busSource;
	}


	public String getBusDestination() {
		return busDestination;
	}


	public void setBusDestination(String busDestination) {
		this.busDestination = busDestination;
	}


	public int getBusFare() {
		return busFare;
	}


	public void setBusFare(int busFare) {
		this.busFare = busFare;
	}


	public int getBusSeats() {
		return busSeats;
	}


	public void setBusSeats(int busSeats) {
		this.busSeats = busSeats;
	}


	public String getBusDate() {
		return busDate;
	}


	public void setBusDate(String busDate) {
		this.busDate = busDate;
	}


	@Override
	public String toString() {
		return "Bus [busId=" + busId + ", busType=" + busType + ", busSource=" + busSource + ", busDestination="
				+ busDestination + ", busFare=" + busFare + ", busSeats=" + busSeats + ", busDate=" + busDate + "]";
	}
	
	
	
	

}
