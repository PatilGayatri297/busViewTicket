package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="transaction")
@SequenceGenerator(name="transactionid", sequenceName="transactionid", initialValue=1001, allocationSize=1)
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="transactionid")
	@Column(name="transactionid")
	private int transactionid;
	@Column(name="transactionfare")
	private int transactionfare;
	@Column(name="transactionemail")
	private String transactionemail;
	public Transaction() {
		super();
	}
	public Transaction(int transactionid, int transactionfare, String transactionemail) {
		super();
		this.transactionid = transactionid;
		this.transactionfare = transactionfare;
		this.transactionemail = transactionemail;
	}
	public int getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}
	public int getTransactionfare() {
		return transactionfare;
	}
	public void setTransactionfare(int transactionfare) {
		this.transactionfare = transactionfare;
	}
	public String getTransactionemail() {
		return transactionemail;
	}
	public void setTransactionemail(String transactionemail) {
		this.transactionemail = transactionemail;
	}
	@Override
	public String toString() {
		return "Transaction [transactionid=" + transactionid + ", transactionfare=" + transactionfare
				+ ", transactionemail=" + transactionemail + "]";
	}
	
	
}
