package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Table(name="admin")
public class Admin {
	@Column(name="adminusername")
	private String adminUsername;
	
	@Column(name="adminpassword")
	private String adminPassword;
	
	
	public Admin() {
		super();
	}


	public Admin(String adminUsername, String adminPassword) {
		super();
		this.adminUsername = adminUsername;
		this.adminPassword = adminPassword;
	}


	public String getAdminUsername() {
		return adminUsername;
	}


	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}


	public String getAdminPassword() {
		return adminPassword;
	}


	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}


	@Override
	public String toString() {
		return "Admin [adminUsername=" + adminUsername + ", adminPassword=" + adminPassword + "]";
	}
	
	
	

}
