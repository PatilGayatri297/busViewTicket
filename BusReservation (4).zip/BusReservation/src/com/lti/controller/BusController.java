package com.lti.controller;

import java.util.List;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Bus;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;
import com.lti.service.BusService;

@Controller
public class BusController {
	
	@Autowired
	private Ticket ticket;
	
	@Autowired
	private BusService service;
	
	@Autowired
	private User user;
	
	@Autowired
	private Bus bus;
	
	@Autowired
	private Transaction transaction;
	
	@Autowired 
	JavaMailSender sender;	
	String emailSender="<quadrobus@gmail.com>";
	
	
	
	@RequestMapping(path="/")
	public String indexPage(){
		return "index";
		
	}
	@RequestMapping(path="addUser.do",  method=RequestMethod.POST)
	public String addUser(@RequestParam("useremail")String email, @RequestParam("userpassword") String password, @RequestParam("usermobile")String mobile){
		user.setUserEmail(email);
		user.setUserPassword(password);
		user.setUserMobile(mobile);
		
		boolean result = service.addUser(user);
		if(result){
			return "success";
		}
		return "Error";
	}
	
	@RequestMapping(path="viewBus.do", method=RequestMethod.GET)
	public String readBus(@RequestParam("bussource")String bussource, @RequestParam("busdestination")String busdestination, Model model){
		bus.setBusSource(bussource);
		bus.setBusDestination(busdestination);
		List<Bus> list = service.findBus(bussource, busdestination);
		model.addAttribute("buslist",list);
		System.out.println(list);
		return "viewBus";
	}
	
	@RequestMapping(path="bookSeat", method=RequestMethod.POST)
	public String bookSeat(){
		return "bookSeat";
	}
	

	@RequestMapping(path="viewTicket", method=RequestMethod.GET)
	public String viewTicket(@RequestParam("transactionid") int id, Model model){
		List<Ticket> list1 = (List<Ticket>) service.displayTicketById(id);
		model.addAttribute("ticketlist", list1);
		System.out.println(list1);
		return "viewTicket";
	}
	
	
	
	  @RequestMapping(value="mail.shop", method = RequestMethod.GET) 
	  public String genOtp() 
	  { 
		  return "Otp"; 
	  }
	  
	  
	  

@RequestMapping(value="validate.shop", method=RequestMethod.GET)
	public String validateOtp( @RequestParam("otp2")String otp2,@RequestParam("customerPassword")String customerPassword, HttpSession session) {
		Object obj= session.getAttribute("otp");
		String mail = (String)session.getAttribute("customerMail");
		String otp=null;
		if(obj!=null) {
			 otp = obj.toString();
		}		
		if(otp.contentEquals(otp2))
		{
			int result = service.forgetPassword(mail, customerPassword);
			if(result>0){
				return "redirect:index";
			}
			else {
			return "password not updated";
			}
		}
		else
		{
			return "redirect:mail.shop";
		}
	}
	  
	 @RequestMapping(path="otp.do", method=RequestMethod.GET)
	 public String otppage(){
		 return "otp";
	 }

		
		@RequestMapping(path="mailotp.shop", method=RequestMethod.GET)
		public String sentOtp(Model model, @RequestParam("emailToRecipient") final String emailToRecipient, HttpSession session ) {
			 
			int randomPin   =(int) (Math.random()*9000)+1000; 
		     final String otp1  = String.valueOf(randomPin); 
		     
	        // Logging The Email Form Parameters For Debugging Purpose
	        //System.out.println("\nReceipient?= " + emailToRecipient + ", Subject?= " + emailSubject + ", Message?= " + emailMessage + "\n");
	 
	        sender.send(new MimeMessagePreparator() {
	            public void prepare(MimeMessage mimeMessage) throws Exception {
	 
	                MimeMessageHelper mimeMsgHelperObj = new MimeMessageHelper(mimeMessage, true, "UTF-8");             
	                mimeMsgHelperObj.setTo(emailToRecipient);
	                mimeMsgHelperObj.setFrom(emailSender);               
	                mimeMsgHelperObj.setText(otp1);
	                mimeMsgHelperObj.setSubject("Your OTP is: ");             
	            }
	        });
	        session.setAttribute("otp", otp1);
	        session.setAttribute("customerMail", emailToRecipient);
	        System.out.println("\nMessage Send Successfully.... Hurrey!\n");
	        model.addAttribute("msg","Mail Sent!");
	       return "forgotpassword";
		}












	

	
	
	
	
	
	
	
	
	
	
}
