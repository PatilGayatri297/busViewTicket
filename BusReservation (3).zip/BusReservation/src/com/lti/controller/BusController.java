package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Bus;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;
import com.lti.service.BusService;

@Controller
public class BusController {
	
	@Autowired
	private Ticket ticket;
	
	@Autowired
	private BusService service;
	
	@Autowired
	private User user;
	
	@Autowired
	private Bus bus;
	
	@Autowired
	private Transaction transaction;
	
	@RequestMapping(path="/")
	public String indexPage(){
		return "index";
		
	}
	@RequestMapping(path="addUser.do",  method=RequestMethod.POST)
	public String addUser(@RequestParam("useremail")String email, @RequestParam("userpassword") String password, @RequestParam("usermobile")String mobile){
		user.setUserEmail(email);
		user.setUserPassword(password);
		user.setUserMobile(mobile);
		
		boolean result = service.addUser(user);
		if(result){
			return "success";
		}
		return "Error";
	}
	
	@RequestMapping(path="viewBus.do", method=RequestMethod.GET)
	public String readBus(@RequestParam("bussource")String bussource, @RequestParam("busdestination")String busdestination, Model model){
		bus.setBusSource(bussource);
		bus.setBusDestination(busdestination);
		List<Bus> list = service.findBus(bussource, busdestination);
		model.addAttribute("buslist",list);
		System.out.println(list);
		return "viewBus";
	}
	
	@RequestMapping(path="bookSeat", method=RequestMethod.POST)
	public String bookSeat(){
		return "bookSeat";
	}
	
/*
	
	@RequestMapping(path="reset_password.do")
	public String resetPassword(){
		return "reset_password";
	}*/
	
	@RequestMapping(path="viewTicket", method=RequestMethod.GET)
	public String viewTicket(@RequestParam("transactionid") int id, Model model){
		List<Ticket> list1 = (List<Ticket>) service.displayTicketById(id);
		model.addAttribute("ticketlist", list1);
		System.out.println(list1);
		
		return "viewTicket";
	}
	
	
	
	
	
	
}
