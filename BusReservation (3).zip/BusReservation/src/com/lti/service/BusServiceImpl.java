package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.BusDao;
import com.lti.model.Bus;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;

@Service("service")
public class BusServiceImpl implements BusService{

	@Autowired
	public BusDao dao;
	
	
	@Override
	public boolean addUser(User user) {		
		int result = getDao().createUser(user);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	@Override
	public List<Bus> findBus(String busSource, String busDestination) {
		return dao.searchBus(busSource, busDestination);
		
	}

	
	public BusDao getDao() {
		return dao;
	}

	public void setDao(BusDao dao) {
		this.dao = dao;
	}
	@Override
	public boolean chooseBus(Transaction transaction) {
		int result= dao.selectBus(transaction);
		if(result==1){
			return true;
		}
		else
			return false;
	}
	@Override
	public Ticket displayTicketById(int transactionid) {
		
		return dao.viewTicketById(transactionid);
	}




}


	
