package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Bus;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;

@Repository
public class BusDaoImpl implements BusDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional 
	public int createUser(User user) {
		entityManager.persist(user);
		return 1;
	}

	@Override
	public List<Bus> searchBus(String busSource, String busDestination ) {
		String query = "SELECT b from Bus b WHERE b.busSource =:source and b.busDestination =:destination";
		TypedQuery<Bus> tquery = entityManager.createQuery(query, Bus.class);
		tquery.setParameter("source", busSource);
		tquery.setParameter("destination", busDestination);
		System.out.println(busSource);
		System.out.println(busDestination);
		
		List<Bus> list=tquery.getResultList();
		System.out.println(list);
		return list;
	}
	
	
	@Override
	public int selectBus(Transaction transaction) {
		entityManager.persist(transaction);
		return 1;
	}

	@Override
	public Ticket viewTicketById(int transactionid) {
		Ticket ticket=entityManager.find(Ticket.class, transactionid);
		return ticket;
	}
/*
	@Override
		
		public int updatePassword(String username, String password) {
			 Query query = entityManager.createQuery("update users u set u.userpassword=:newPass WHERE u.useremail=:user");
			 query.setParameter("newPass", password);
			 query.setParameter("user", username);
			 int rowsUpdated = query.executeUpdate();
			 return rowsUpdated;
		}*/

		
	}
	
	

	


