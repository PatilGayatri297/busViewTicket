package com.lti.dao;

import java.util.List;

import com.lti.model.Bus;
import com.lti.model.Ticket;
import com.lti.model.Transaction;
import com.lti.model.User;

public interface BusDao {
	public int createUser(User user);
	public List<Bus> searchBus(String busSource, String busDestination);
	public int selectBus(Transaction transaction);
	public Ticket viewTicketById(int transactionid);
	//public int updatePassword(String username, String password);
	
}
