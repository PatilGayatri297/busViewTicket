package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="ticket")
@SequenceGenerator(name="ticketid", sequenceName="ticketid", initialValue=1, allocationSize=1)
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ticketid")
	@Column(name="ticketid")
	private int ticketid;
	@Column(name="transactionid")
	private int transactionid;
	@Column(name="email")
	private String email;
	@Column(name="bookedseat")
	private int bookedseat;
	@Column(name="busid")
	private int busid;
	@Column(name="ticketdestination")
	private String ticketdestination;
	@Column(name="ticketsource")
	private String ticketsource;
	@Column(name="ticketfare")
	private int ticketfare;
	public Ticket() {
		super();
	}
	public Ticket(int ticketid, int transactionid, String email, int bookedseat, int busid, String ticketdestination,
			String ticketsource, int ticketfare) {
		super();
		this.ticketid = ticketid;
		this.transactionid = transactionid;
		this.email = email;
		this.bookedseat = bookedseat;
		this.busid = busid;
		this.ticketdestination = ticketdestination;
		this.ticketsource = ticketsource;
		this.ticketfare = ticketfare;
	}
	public int getTicketid() {
		return ticketid;
	}
	public void setTicketid(int ticketid) {
		this.ticketid = ticketid;
	}
	public int getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getBookedseat() {
		return bookedseat;
	}
	public void setBookedseat(int bookedseat) {
		this.bookedseat = bookedseat;
	}
	public int getBusid() {
		return busid;
	}
	public void setBusid(int busid) {
		this.busid = busid;
	}
	public String getTicketdestination() {
		return ticketdestination;
	}
	public void setTicketdestination(String ticketdestination) {
		this.ticketdestination = ticketdestination;
	}
	public String getTicketsource() {
		return ticketsource;
	}
	public void setTicketsource(String ticketsource) {
		this.ticketsource = ticketsource;
	}
	public int getTicketfare() {
		return ticketfare;
	}
	public void setTicketfare(int ticketfare) {
		this.ticketfare = ticketfare;
	}
	@Override
	public String toString() {
		return "Ticket [ticketid=" + ticketid + ", transactionid=" + transactionid + ", email=" + email
				+ ", bookedseat=" + bookedseat + ", busid=" + busid + ", ticketdestination=" + ticketdestination
				+ ", ticketsource=" + ticketsource + ", ticketfare=" + ticketfare + "]";
	}
	
	



	
	
	
}

