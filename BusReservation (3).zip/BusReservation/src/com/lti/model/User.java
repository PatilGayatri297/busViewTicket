package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="users")
public class User {
	@Id
	@Column(name="useremail")
	private String userEmail;
	
	@Column(name="userpassword")
	private String userPassword;
	
	@Column(name="usermobile")
	private String userMobile;
	
	@Column(name="userbalance")
	private int userBalance;
	
	
	public User() {
		super();
	}


	public User(String userEmail, String userPassword, String userMobile, int userBalance) {
		super();
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.userMobile = userMobile;
		this.userBalance = userBalance;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getUserMobile() {
		return userMobile;
	}


	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}


	public int getUserBalance() {
		return userBalance;
	}


	public void setUserBalance(int userBalance) {
		this.userBalance = userBalance;
	}


	@Override
	public String toString() {
		return "User [userEmail=" + userEmail + ", userPassword=" + userPassword + ", userMobile=" + userMobile
				+ ", userBalance=" + userBalance + "]";
	}
	
	
	

}
